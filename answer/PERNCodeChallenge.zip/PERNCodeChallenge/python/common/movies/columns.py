default_movie_columns = ['movie_id', 'avg_rating', 'created_at', 'updated_at', 'title', 'rating_classification', 'description', 'release_date', 'runtime']

movie_columns_wo_id = ['avg_rating', 'created_at', 'updated_at', 'title', 'rating_classification','description', 'release_date', 'runtime']
