json_success = {
    'meta': {},
    'data': {
        'message': ''
    }
}
